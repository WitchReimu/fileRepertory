# Android内存泄漏

内存泄漏（Memory Leak)：是指程序中己动态分配的堆内存由于某种原因**程序未释放**或**无法释放**，造成**系统内存的浪费**，导致程序运行速度减慢甚至系统崩溃等严重后果。

比如：当Activity的onDestroy()方法被调用后，Activity以及它涉及到的View和相关的Bitmap都应该被回收掉。但是，如果有一个后台线程做耗时操作，导致生命周期比Activity长，造成GC无法回收Activity，就造成内存泄漏。
## 常见的内存泄漏
### 单例造成的内存泄漏
单例在Android中经常使用，如果使用不当会造成内存泄漏，因为单例的静态特性使得他的生命周期与应用的生命周期一样长，这就造成**当前对象的生命周期比单例短，单例又持有该对象的引用，GC无法回收该对象，就这导致内存泄漏**，比如Context使用不当： 这里的Context如果使用的是activity的Context，造成单例持有activity的引用，它的生命周期又是整个应用的生命周期，导致activity无法销毁。则有可能造成内存泄漏，

比如：
```java
public class LoginManager {
    private static LoginManager mInstance;
    private Context mContext;

    //问题代码
    private LoginManager(Context context) {
        this.mContext = context;          
        //修改代码：this.mContext = context.getApplicationContext();
    }
    public static LoginManager getInstance(Context context) {
        if (mInstance == null) {
            synchronized (LoginManager.class) {
                if (mInstance == null) {
                    mInstance = new LoginManager(context);
                }
            }
        }
        return mInstance;
    }
    public void get() {}
}
```
使用场景： 在一个Activity中调用的，然后关闭该Activity则会出现内存泄漏。 LoginManager.getInstance(this).get();

解决方案： 可以将Context修改为AppLication的Context，代码如下：this.mContext = context.getApplicationContext();此时传入的是 Application 的 Context，因为 Application 的生命周期就是整个应用的生命周期，此时Context就和整个应用的生命周期一样，与单例的生命周期一样，单例持有的是整个application的引用，与activity无关，此时activity就正常可以销毁了，所以这将没有任何问题。 非静态内部类造成的内存泄漏
### 非静态内部类造成的内存泄漏
比如：
```java
public class TestLeak extends AppCompatActivity {
    private static InnerClass mInnerClass = null;    
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_test);
        if (mInnerClass == null) {
            mInnerClass = new InnerClass();
        }
    }    
    class InnerClass {
    }
}
```
代码中有一个非静态内部类InnerClass，有一个静态变量mInnerClass，在onCreate中进行了初始化操作，这个内部类实例就持有activity的强引用，而**静态变量的生命周期与应用的生命周期一样长，而activity的生命周期比它短，想要销毁时，被持有引用，无法回收，继而造成内存泄漏。** 

解决方案： 1.将内部类设置为静态内部类，静态内部类不会持有外部类的引用。
比如：
```java
public class TestLeak extends AppCompatActivity {
    private static InnerClass mInnerClass = null;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_test);
        if (mInnerClass == null) {
            mInnerClass = new InnerClass();
        }
    }
    static class InnerClass {
    }
}
```
2.将该内部类抽取出来封装成一个单例，使用Application的Context。
```java
public class InnerClass {
    private volatile static InnerClass instance;

    private InnerClass(Context context) {
    }

    public static InnerClass getInstance(Context context) {
        if (instance == null) {
            synchronized (InnerClass.class) {
                if (instance == null) {
                    instance = new InnerClass(context.getApplicationContext());
                }
            }
        }
        return instance;
    }
}
public class TestLeak extends AppCompatActivity {
    private static InnerClass mInnerClass = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_test);
        if (mInnerClass == null) {
            mInnerClass = InnerClass.getInstance(this);
        }
    }
}
```
3.在activity销毁时，将静态内部类设置为空
```java
@Override
    protected void onDestroy() {
        mInnerClass = null;
        super.onDestroy();
    }
```
### 线程造成的内存泄漏

线程造成的内部泄漏以AsyncTask为例

比如：
```java
ublic class MainActivity extends AppCompatActivity {

    private AsyncTask<Void, Void, Integer> asyncTask;
    private TextView mTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTextView = (TextView) findViewById(R.id.text);
        testAsyncTask();
        finish();
    }
    private void testAsyncTask() {
        asyncTask = new AsyncTask<Void, Void, Integer>() {
            @Override
            protected Integer doInBackground(Void... params) {
                int i = 0;
                //模拟耗时操作
                while (!isCancelled()) {
                    i++;
                    if (i > 1000) {
                        break;
                    }

                }
                return i;
            }

            @Override
            protected void onPostExecute(Integer integer) {
                super.onPostExecute(integer);
                mTextView.setText(String.valueOf(integer));
            }
        };
        asyncTask.execute();
    }
}
```
造成内存泄漏原因分析:

在处理一个比较耗时的操作时，可能还没处理结束MainActivity就执行了退出操作，这时候**线程的生命周期比activity长，又AsyncTask依然持有对MainActivity的引用，最后导致MainActivity无法被GC回收引发内存泄漏。** 解决方案： 在Activity销毁时候也应该取消相应的任务AsyncTask.cancel()方法，避免任务在后台执行浪费资源，进而避免内存泄漏的发生
### 不需要用的监听未移除会发生内存泄露
比如： add监听(add监听是通知者模式)，放到集合里面
```java
tv.getViewTreeObserver().addOnWindowFocusChangeListener(new ViewTreeObserver.OnWindowFocusChangeListener() {
    @Override
    public void onWindowFocusChanged(boolean b) {
        //监听view的加载，view加载出来的时候，计算他的宽高等。
    }
});
```
解决方案 计算完后，一定要移除这个监听
```java
tv.getViewTreeObserver().removeOnWindowFocusChangeListener(this);
```
### 资源未关闭造成的内存泄漏
**BroadcastReceiver，ContentObserver，FileObserver，Cursor，Callback，EventBus**等在Activity onDestroy 或者某类**生命周期结束之后一定要unregister或者close掉**，否则这个 Activity 类会被系统强引用，不会被内存回收。值得注意的是，关闭的语句必须在finally中进行关闭，否则有可能因为异常未关闭资源，致使activity泄漏。
### 动画资源未释放导致内存泄漏
比如：
```java
public class LeakActivity extends AppCompatActivity {
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leak);
        textView = (TextView)findViewById(R.id.text_view);
        ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(textView,"rotation",0,360);
        objectAnimator.setRepeatCount(ValueAnimator.INFINITE);
        objectAnimator.start();
    }
}
```
解决方案： 在属性动画中有一类无限循环动画，如果在Activity中播放这类动画并且在onDestroy中不去停止动画，**那么这个动画将会一直播放下去，这时候Activity会被View所持有，从而导致Activity无法被释放**。解决此类问题则是需要早Activity中onDestroy去去调用objectAnimator.cancel()来停止动画。
```java
@Override
protected void onDestroy() {
    super.onDestroy();
    mAnimator.cancel();
}
```
### 系统bug之InputMethodManager导致内存泄漏
```java
public class MemoryLeakUtil {

    public static void fixInputMethodMemoryLeak(Context context) {
        if (context == null)
            return;
        InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputMethodManager == null)
            return;

        String[] viewArr = new String[]{"mCurRootView", "mServedView", "mNextServedView"};
        Field field;
        Object fieldObj;
        for (String view : viewArr) {
            try {
                field = inputMethodManager.getClass().getDeclaredField(view);
                if (!field.isAccessible()) {
                    field.setAccessible(true);
                }
                fieldObj = field.get(inputMethodManager);
                if (fieldObj != null && fieldObj instanceof View) {
                    View fieldView = (View) fieldObj;
                    if (fieldView.getContext() == context) {
                        //注意需要判断View关联的Context是不是当前Activity，否则有可能造成正常的输入框输入失效
                        field.set(inputMethodManager, null);
                    } else {
                        break;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}
```
最后在泄漏的Activity，调用工具类
```java
@Override
    protected void onDestroy() {
        //手动切断InputMethodManager里的View引用链
        MemoryLeakUtil.fixInputMethodMemoryLeak(this);
        super.onDestroy();
    }
```
