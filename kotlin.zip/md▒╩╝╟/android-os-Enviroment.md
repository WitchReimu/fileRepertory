android获取手机外部存储文件路径
```kotlin
Environment.getExternalStorageDirectory()
```
以上方法在高版本android系统已经被弃用
**应使用一下方法**
```kotlin
/**
* @param
     *           android.os.Environment#DIRECTORY_MUSIC,
     *           android.os.Environment#DIRECTORY_PODCASTS,
     *           android.os.Environment#DIRECTORY_RINGTONES,
     *           android.os.Environment#DIRECTORY_ALARMS,
     *           android.os.Environment#DIRECTORY_NOTIFICATIONS,
     *           android.os.Environment#DIRECTORY_PICTURES, 
     *           android.os.Environment#DIRECTORY_MOVIES.
     */
Context.getExternalFilesDir(String type)
```
