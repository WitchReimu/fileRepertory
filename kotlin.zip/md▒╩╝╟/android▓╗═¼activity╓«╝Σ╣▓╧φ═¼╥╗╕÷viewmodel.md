viewmodel的创建根据viewModelStoreOwner与key来进行判断

如果viewModelStoreOwner与key是相同的，那么创建的viewmodel就是相同的


```kotlin
class ShareActivity : AppCompatActivity() {

    private lateinit var viewModel: CommonViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_common)
        viewModel = ViewModelProvider(this).get("CommonViewModel", CommonViewModel::class.java)
        ShareViewModelStoreOwner.viewModelStoreOwner = this
        Log.i("TAG", "onCreate: -->$viewModel")
        val intent = Intent(this, ShareActivity1::class.java)
        startActivity(intent)
    }
}
```

这个类用来保存ShareActivity的viewModelStoreOwner
```kotlin
object ShareViewModelStoreOwner {

    lateinit var viewModelStoreOwner:ViewModelStoreOwner
}
```

```kotlin
class ShareActivity1 : AppCompatActivity() {

    private lateinit var viewModel: CommonViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_common)
        viewModel = ViewModelProvider(ShareViewModelStoreOwner.viewModelStoreOwner).get(
            "CommonViewModel",
            CommonViewModel::class.java
        )
        Log.i("TAG", "onCreate: -->$viewModel")
    }
}
```