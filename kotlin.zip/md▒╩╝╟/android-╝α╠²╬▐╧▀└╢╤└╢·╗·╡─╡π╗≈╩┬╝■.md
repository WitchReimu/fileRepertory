# Android如何监听无线蓝牙耳机的点击事件


蓝牙的监听需要使用到MediaSessionCompat类中的callback接口回调

```java
private MediaSessionCompat.Callback callback = new MediaSessionCompat.Callback() {
        @Override
        public void onPlay() {
            super.onPlay();
        }

        @Override
        public boolean onMediaButtonEvent(Intent mediaButtonEvent) {
            String intentAction = mediaButtonEvent.getAction();
            if (Intent.ACTION_MEDIA_BUTTON.equals(intentAction)) {
                KeyEvent event = mediaButtonEvent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);

                if (event != null) {
                    if (event.getAction() == KeyEvent.ACTION_UP) {
                        switch (event.getKeyCode()) {
                            case KeyEvent.KEYCODE_MEDIA_PLAY:
                                Log.i(TAG, "onMediaButtonEvent: -->音乐播放");
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                                Log.i(TAG, "onMediaButtonEvent: -->音乐暂停");
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                                Toast.makeText(getApplication(), "Fast forward is pressed!", Toast.LENGTH_SHORT).show();
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_NEXT:
                                Toast.makeText(getApplication(), "Next is pressed!", Toast.LENGTH_SHORT).show();
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                                Toast.makeText(getApplication(), "Play is pressed!", Toast.LENGTH_SHORT).show();
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                                Log.i(TAG, "onMediaButtonEvent: -->上一首");
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_REWIND:
                                Toast.makeText(getApplication(), "Rewind is pressed!", Toast.LENGTH_SHORT).show();
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_STOP:
                                Toast.makeText(getApplication(), "Stop Button is pressed!", Toast.LENGTH_SHORT).show();
                                return true;
                            case KeyEvent.KEYCODE_VOLUME_UP:
                                Toast.makeText(getApplication(), "Volume up is pressed!", Toast.LENGTH_SHORT).show();
                                return true;
                            case KeyEvent.KEYCODE_VOLUME_DOWN:
                                Toast.makeText(getApplication(), "Volume down is pressed!", Toast.LENGTH_SHORT).show();
                                return true;

                        }
                    }
                    return false;
                }
            }
            return super.onMediaButtonEvent(mediaButtonEvent);
        }
    };
```

在服务创建时创建一个MediaSessionCompat对象并设置上文中的回调。
```java
@Override
    public void onCreate() {
        Log.i(TAG, "onCreate: -->服务开启");
        mMediaSession = new MediaSessionCompat(this, "MEDIA");
        mMediaSession.setCallback(callback);
//        mMediaSession.setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS | MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS);
        PlaybackStateCompat.Builder mStateBuilder = new PlaybackStateCompat.Builder().setActions(PlaybackStateCompat.ACTION_PLAY |
                PlaybackStateCompat.ACTION_PAUSE |
                PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS |
                PlaybackStateCompat.ACTION_SKIP_TO_NEXT |
                PlaybackStateCompat.ACTION_PLAY_PAUSE);
        mMediaSession.setPlaybackState(mStateBuilder.build());
        mMediaSession.setActive(true);
    }
```

```java
 @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        MediaButtonReceiver.handleIntent(mMediaSession, intent);
        return super.onStartCommand(intent, flags, startId);
    }
```
MediaButtonReceiver类是androix内自带的类。

service与MediaButtonReceiver在manifest文件中注册时需要的意图过滤
```xml
<service
            android:name=".blue.BluetoothListenerService"
            android:enabled="true"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MEDIA_BUTTON" />
            </intent-filter>
        </service>

        <receiver
            android:name="androidx.media.session.MediaButtonReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MEDIA_BUTTON" />
            </intent-filter>
        </receiver>
```
以上监听需要在程序已经在播放状态才会触发回调监听。

整个服务的代码
```java
public class BluetoothListenerService extends Service {

    private static final String TAG = "BluetoothListenerServic";

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private MediaSessionCompat.Callback callback = new MediaSessionCompat.Callback() {
        @Override
        public void onPlay() {
            super.onPlay();
        }

        @Override
        public boolean onMediaButtonEvent(Intent mediaButtonEvent) {
            String intentAction = mediaButtonEvent.getAction();
            if (Intent.ACTION_MEDIA_BUTTON.equals(intentAction)) {
                KeyEvent event = mediaButtonEvent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);

                if (event != null) {
                    if (event.getAction() == KeyEvent.ACTION_UP) {
                        switch (event.getKeyCode()) {
                            case KeyEvent.KEYCODE_MEDIA_PLAY:
                                Log.i(TAG, "onMediaButtonEvent: -->音乐播放");
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                                Log.i(TAG, "onMediaButtonEvent: -->音乐暂停");
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                                Toast.makeText(getApplication(), "Fast forward is pressed!", Toast.LENGTH_SHORT).show();
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_NEXT:
                                Toast.makeText(getApplication(), "Next is pressed!", Toast.LENGTH_SHORT).show();
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                                Toast.makeText(getApplication(), "Play is pressed!", Toast.LENGTH_SHORT).show();
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                                Log.i(TAG, "onMediaButtonEvent: -->上一首");
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_REWIND:
                                Toast.makeText(getApplication(), "Rewind is pressed!", Toast.LENGTH_SHORT).show();
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_STOP:
                                Toast.makeText(getApplication(), "Stop Button is pressed!", Toast.LENGTH_SHORT).show();
                                return true;
                            case KeyEvent.KEYCODE_VOLUME_UP:
                                Toast.makeText(getApplication(), "Volume up is pressed!", Toast.LENGTH_SHORT).show();
                                return true;
                            case KeyEvent.KEYCODE_VOLUME_DOWN:
                                Toast.makeText(getApplication(), "Volume down is pressed!", Toast.LENGTH_SHORT).show();
                                return true;

                        }
                    }
                    return false;
                }
            }
            return super.onMediaButtonEvent(mediaButtonEvent);
        }
    };
    private MediaSessionCompat mMediaSession;

    @Override
    public void onCreate() {
        Log.i(TAG, "onCreate: -->服务开启");
        mMediaSession = new MediaSessionCompat(this, "MEDIA");
        mMediaSession.setCallback(callback);
//        mMediaSession.setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS | MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS);
        PlaybackStateCompat.Builder mStateBuilder = new PlaybackStateCompat.Builder().setActions(PlaybackStateCompat.ACTION_PLAY |
                PlaybackStateCompat.ACTION_PAUSE |
                PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS |
                PlaybackStateCompat.ACTION_SKIP_TO_NEXT |
                PlaybackStateCompat.ACTION_PLAY_PAUSE);
        mMediaSession.setPlaybackState(mStateBuilder.build());
        mMediaSession.setActive(true);
    }

    @Override
    public void onDestroy() {
        Log.i(TAG, "onDestroy: -->服务被销毁");
        mMediaSession.release();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        MediaButtonReceiver.handleIntent(mMediaSession, intent);
        return super.onStartCommand(intent, flags, startId);
    }
}
```