# BtoomSheet
与主界面**同层级**关系，可以事件触发，如果有设置显示高度的话，也可以拉出来，且不会影响主界面的交互。

```xml
 <androidx.coordinatorlayout.widget.CoordinatorLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintLeft_toLeftOf="parent">

        <LinearLayout
            android:id="@+id/ll_bottom_sheet"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="vertical"
            app:behavior_peekHeight="0dp"
            app:layout_behavior="@string/bottom_sheet_behavior">


            <TextView
                android:layout_width="match_parent"
                android:layout_height="80dp"
                android:background="@android:color/holo_red_light"
                android:gravity="center"
                android:text="上拉解锁隐藏功能"
                android:textColor="@color/white"
                android:textSize="20sp" />

            <TextView
                android:layout_width="match_parent"
                android:layout_height="80dp"
                android:background="@android:color/holo_blue_light"
                android:gravity="center"
                android:text="a"
                android:textSize="20sp" />

            <TextView
                android:layout_width="match_parent"
                android:layout_height="80dp"
                android:background="@android:color/holo_orange_dark"
                android:gravity="center"
                android:text="b"
                android:textSize="20sp" />

            <TextView
                android:layout_width="match_parent"
                android:layout_height="80dp"
                android:background="@android:color/holo_green_light"
                android:gravity="center"
                android:text="c"
                android:textSize="20sp" />
        </LinearLayout>
    </androidx.coordinatorlayout.widget.CoordinatorLayout>
```
- 必须用CoordinatorLayout包裹
- 必须使用app:layout_behavior 标示这是一个bottom_sheet
- 必须使用app:behavior_peekHeight显示高度，不显示的话设置为0即可

activity中调用
```kotlin
binding.bottomsheet.setOnClickListener {
            val behavior = BottomSheetBehavior.from(binding.llBottomSheet)
            if (behavior.state == BottomSheetBehavior.STATE_EXPANDED) {
                behavior.state = BottomSheetBehavior.STATE_COLLAPSED
            } else {
                behavior.state = BottomSheetBehavior.STATE_EXPANDED
            }
        }
```
# BottomSheetDialog
activity中简单使用
```kotlin
            val bottomSheetDialog = BottomSheetDialog(this)
            bottomSheetDialog.setContentView(R.layout.dialog_bottom_sheet)
            bottomSheetDialog.show()
```
或者继承BottomSheetDialog
```kotlin
class ZuidaBottomSheetDialog : BottomSheetDialog {

    constructor(context: Context) : super(context)

    constructor(context: Context, theme: Int) : super(context, theme)

    constructor(
        context: Context,
        cancelable: Boolean,
        cancelListener: DialogInterface.OnCancelListener?
    ) : super(context, cancelable, cancelListener)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding = RecycleTestBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.testRecycler.layoutManager =
            LinearLayoutManager(context, RecyclerView.VERTICAL, false)
        binding.testRecycler.adapter = TestRecyAdapter()
        val screenHeight = getScreenHeight(context)

        val dialogHeight = if (screenHeight == 0) {
            screenHeight
        } else {
            ViewGroup.LayoutParams.MATCH_PARENT
        }
        val window = window
        window?.let {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, 960)

            //需要设置最大高度
            //你想要减去的高度，dialog默认最大高度在状态栏下方
//            val reduceHeight = getContext().getResources().getDimension(R.dimen.maxHeight);
//            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,
//                (dialogHeight - reduceHeight).toInt()
//            );
            //最后一步是必须的，否贼BottomSheetDialog会显示在屏幕中间，底部会出现空白区域
            window.setGravity(Gravity.BOTTOM);
        }

    }

    private fun setPeekHeight(peekHeight: Int) {
        if (peekHeight <= 0) {
            return
        }
        val bottomSheetBehavior = getBottomSheetBehavior()
        bottomSheetBehavior?.peekHeight = peekHeight
    }

    private fun getBottomSheetBehavior(): BottomSheetBehavior<View>? {
        val view: View? = window?.findViewById(com.google.android.material.R.id.design_bottom_sheet)
        return view?.let { BottomSheetBehavior.from(view) }
    }

    private fun getScreenHeight(context: Context): Int {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val point = Point()
        windowManager.defaultDisplay.getSize(point)
        return point.y
    }
}
```

# BottomSheetDialogFragment
```kotlin
class Bottom : BottomSheetDialogFragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.BottomSheetDialog)

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val inflate = inflater.inflate(R.layout.activity_bottom_container, container, false)
        val btn = inflate.findViewById<Button>(R.id.pop_dialog)
        btn.setOnClickListener {
            dismiss()
        }
        return inflate
    }


    
    override fun onAttach(context: Context) {
        super.onAttach(context)
        val callback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                Log.i(javaClass.simpleName, "handleOnBackPressed: -->1111")
            }
        }

        requireActivity().onBackPressedDispatcher.addCallback(this, callback)
    }
```
activity中调用
```kotint
val bottom = Bottom()
            bottom.show(supportFragmentManager, "one")
```

# 设置bottomsheet背景
```xml
    <!--实现BottomSheetDialog原有背景透明效果-->
    <style name="BottomSheetDialog" parent="Theme.Design.Light.BottomSheetDialog">
        <item name="bottomSheetStyle">@style/bottomSheetStyleWrapper</item>
    </style>
    <style name="bottomSheetStyleWrapper" parent="Widget.Design.BottomSheet.Modal">
        <item name="android:background">@android:color/transparent</item>
    </style>

```