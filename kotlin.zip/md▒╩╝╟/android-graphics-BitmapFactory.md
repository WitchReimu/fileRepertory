从指定文件中获取
```kotlin
val file = File(Environment.getExternalStorageDirectory(), "cropper/test")
        val detailFile = File(file, "213213124.jpg")
        if (detailFile.exists()){
            val bm = BitmapFactory.decodeFile(file.absolutePath)
        }else{
            Log.i("TAG", "onCreate: -->文件不存在")
        }
```
从指定本地资源中获取
```kotlin
BitmapFactory.decodeResource(resources,R.mipmap.ic_launcher_round)
```