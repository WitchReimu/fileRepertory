# 自定义一个简单的layoutmanager
## 创建一个自定义layoutmanager类
创建一个HorizontalLayoutManager类继承于LayoutManager，重写方法generateDefaultLayoutParams()，如果没有特殊要求默认返回RecyclerView.LayoutParams。
```kotlin
class HorizontalLayoutManager : RecyclerView.LayoutManager() {
    override fun generateDefaultLayoutParams(): RecyclerView.LayoutParams {
        return RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }
}
```
然后替换RecyclerView的LayoutManager
```kotlin
recyclerView.layoutManager = HorizontalLayoutManager()
```
运行后，界面是背景色，因为recycleview的子view是其中layoutmanager中绘制的。(类似viewgroup需要重写onlayout方法)
## 绘制RecyclerView子View
在HorizontalLayoutManager中可以重写onLayoutChildren方法绘制子View。
```kotlin
override fun onLayoutChildren(recycler: RecyclerView.Recycler, state: RecyclerView.State) {
        //分离并且回收当前附加的所有View
        detachAndScrapAttachedViews(recycler)
 
        if (itemCount == 0) {
            return
        }
        //横向绘制子View,则需要知道 X轴的偏移量
        var offsetX = 0
 
        //绘制并添加view
        for (i in 0 until itemCount) {
            val view = recycler.getViewForPosition(i)
            addView(view)
 
            measureChildWithMargins(view, 0, 0)
            val viewWidth = getDecoratedMeasuredWidth(view)
            val viewHeight = getDecoratedMeasuredHeight(view)
            layoutDecorated(view, offsetX, 0, offsetX + viewWidth, viewHeight)
            offsetX += viewWidth
        }
    }
```
此时子View已绘制完成，但还无法滑动，所以需要添加滑动代码。
## 添加滑动功能
要实现的是横向滑动功能，所以只重写横向滑动的对应方法，与之对应的还有竖向的方法。

```kotlin
 //是否可横向滑动
    override fun canScrollHorizontally(): Boolean {
        return true
    }
    
    override fun scrollHorizontallyBy(
        dx: Int, recycler: RecyclerView.Recycler, state: RecyclerView.State
    ): Int {
        //日志显示，手指向左滑dx值为正数，手指向右滑dx值为负数
        Log.i("TAG", "----------dx：$dx")
        /**
         * 横向移动所有子View
         * 为什么要 * -1 ? 屏幕xy轴原点在左上角，左移则需要View的坐标 x - offset  右移则需要 x + offset
         * 所以需要 dx * -1
         */
        offsetChildrenHorizontal(dx * -1)
        return dx
    }
```
横向滑动实现了，显示完所有子View后在滑动就是空白了，正常情况下还需要判断是否滑到头、尾了。实现的是无限循环横向滑动，所以只需往右滑滑倒第0个时然后往左边绘制并添加最后一个子View，往左滑滑到最后一个时，在右边在添加第0个子View。实现无限循环滑动。
## 实现横向循环滑动的LayoutManager
我们写一个fill()方法
```kotlin
//为什么大多文章都定义方法名为fill? 我想是因为Android提供的3个LayoutManager都用的此方法名吧
//我看了是真的!!
    private fun fill(dx: Int, recycler: RecyclerView.Recycler) {
        //左滑
        if (dx > 0) {
            //得到当前已添加（可见）的最后一个子View
            val lastVisibleView = getChildAt(childCount - 1) ?: return
            //得到View对应的位置
            val layoutPosition = getPosition(lastVisibleView)
            /**
             * 例如要显示20个View，当前可见的最后一个View就是第20个，那么下一个要显示的就是第一个
             * 如果当前显示的View不是第20个，那么就显示下一个，如当前显示的是第15个View，那么下一个显示第16个
             * 注意区分 childCount 与 itemCount
             */
            val nextView: View = if (layoutPosition == itemCount - 1) {
                recycler.getViewForPosition(0)
            } else {
                recycler.getViewForPosition(layoutPosition + 1)
            }
 
            addView(nextView)
            measureChildWithMargins(nextView, 0, 0)
            val viewWidth = getDecoratedMeasuredWidth(nextView)
            val viewHeight = getDecoratedMeasuredHeight(nextView)
            val offsetX = lastVisibleView.right
            layoutDecorated(nextView, offsetX, 0, offsetX + viewWidth, viewHeight)
        } else { //右滑
            val firstVisibleView = getChildAt(0) ?: return
            val layoutPosition = getPosition(firstVisibleView)
            /**
             * 如果当前第一个可见View为第0个，则左侧显示第20个View 如果不是，下一个就显示前一个
             */
            val nextView = if (layoutPosition == 0) {
                recycler.getViewForPosition(itemCount - 1)
            } else {
                recycler.getViewForPosition(layoutPosition - 1)
            }
 
            addView(nextView, 0)
            measureChildWithMargins(nextView, 0, 0)
            val viewWidth = getDecoratedMeasuredWidth(nextView)
            val viewHeight = getDecoratedMeasuredHeight(nextView)
            val offsetX = firstVisibleView.left
            layoutDecorated(nextView, offsetX - viewWidth, 0, offsetX, viewHeight)
        }
    }
```
## 绘制数量限制
//自定义的layoutmanager并不会自己实现布局服用缓存处理。需要自己决定何时复用view何时回收view

在前面的基础上，绘制子View时，超出RecyclerView范围则不绘制子View。
```kotlin
override fun onLayoutChildren(recycler: RecyclerView.Recycler, state: RecyclerView.State) {
 
        ...
        var offsetX = 0
 
        //绘制并添加view
        for (i in 0 until itemCount) {
 
            ...
 
            offsetX += viewWidth
            
            if (offsetX > width){
                break
            }
        }
    }
```
在滑动时，如果当前两侧的View滑动后还是未完全展示出来，就不绘制下一个View。

还有个问题就：绘制完下一个View后，RecyclerView偏移 dx，当dx大于子View的宽度时，就会出现子View数量未绘制完,RecyclerView显白色的问题，前面没这个问题的原因是没加绘制条件，滑动时在不断绘制子View，修改后的代码如下。 
```kotlin
private fun fill(dx: Int, recycler: RecyclerView.Recycler) {
        //左滑
        if (dx > 0) {
 
            while (true) {
                //得到当前已添加（可见）的最后一个子View
                val lastVisibleView = getChildAt(childCount - 1) ?: break
 
                //如果滑动过后，View还是未完全显示出来就 不进行绘制下一个View
                if (lastVisibleView.right - dx > width)
                    break
 
               ...
            }
        } else { //右滑
            while (true) {
                val firstVisibleView = getChildAt(0) ?: break
 
                if (firstVisibleView.left - dx < 0) break
 
                ...
            }
        }
    }
```
## 回收子View
当子View超出RecyclerView的范围时，就移除并回收子View
```kotlin
private fun recycleViews(dx: Int, recycler: RecyclerView.Recycler) {
        for (i in 0 until itemCount) {
            val childView = getChildAt(i) ?: return
            //左滑
            if (dx > 0) {
                //移除并回收 原点 左侧的子View
                if (childView.right - dx < 0) {
                    removeAndRecycleViewAt(i, recycler)
                }
            } else { //右滑
                //移除并回收 右侧即RecyclerView宽度之以外的子View
                if (childView.left - dx > width) {
                    removeAndRecycleViewAt(i, recycler)
                }
            }
        }
    }
```
因为滑动时在不断添加绘制View，所以对应的也应移除回收View

scrollHorizontallyBy 完整后的代码
```kotlin
override fun scrollHorizontallyBy(
        dx: Int, recycler: RecyclerView.Recycler, state: RecyclerView.State
    ): Int {
        recycleViews(dx, recycler)
        fill(dx, recycler)
        offsetChildrenHorizontal(dx * -1)
        return dx
    }
```
# 总结
- RecyclerView自己具有绘制、回收、缓存复用子View的方法，但需要在LayoutManager调用
- 回收View是根据RecyclerView的宽或高来判断的，所以想要具有缓存复用功能，RecyclerView一定要有确定的宽或高。
- getChildCount() 是得到RecyclerView中显示的Item个数
- getItemCount() 是得到Adapter中设置的需要显示的item个数
- getChildAt(int position) 是从当前屏幕显示的View中对应位置的View
- getPosition(View view) 得到View对应Adapter中的索引位置
- recycler.getViewForPosition(position) 是复用View的关键