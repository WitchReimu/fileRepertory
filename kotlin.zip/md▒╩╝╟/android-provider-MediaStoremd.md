通过MediasStore保存图片
```kotlin
/**
*@param cr 通过Context. getContentResolver
*@param imagePath 图片保存的路径
*@param name 图片保存的名字
*@param description 对于图片的描述
*/
 MediaStore.Images.Media.insertImage(
     cr: ContentResolver?,
        imagePath: String?,
        name: String?,
        description: String?,)
```
```kotlin
        val filedir = File(Environment.getExternalStorageDirectory(), "cropper/test")
        if (!filedir.exists()) {
            filedir.mkdir()
        }
        val filename = "${System.currentTimeMillis()}.jpg"
        val file = File(filedir, filename)
        val fos = FileOutputStream(file)
        MediaStore.Images.Media.insertImage(applicationContext.contentResolver,
            file.absolutePath,
            filename,
            "测试图片")
        this.sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
            Uri.fromFile(File(file.path))))
        Toast.makeText(this, "文件保存到${file.path}", Toast.LENGTH_SHORT).show()
```
以上方法以在高版本andorid系统中被弃用
- [ ] 记录替代方法
**新的api方法真的是狗都不用**
