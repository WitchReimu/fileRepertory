# bitmap处理
## BitmapFactory.options
### inPreferredConfig
**inperferredConfig参数**

**inperferredConfig表示图片解码时使用的颜色模式:**
- inpreferredConfig参数有四个值
- ALPHA_8: 每个像素用占8位,存储的是图片的透明值,占1个字节
- RGB_565:每个像素用占16位,分别为5-R,6-G,5-B通道,占2个字节
- ARGB-4444:每个像素占16位,即每个通道用4位表示,占2个字节
- ARGB_8888:每个像素占32位,每个通道用8位表示,占4个字节

### 优化Bitmap的内存使用(inBitmap)
BitmapFactory.Options.inBitmap字段。如果这个值被设置了，decode方法会在加载内容的时候去reuse已经存在的bitmap. 这意味着bitmap的内存是被reused的，这样可以提升性能, 并且减少了内存的allocation与de-allocation.

- reused的bitmap必须和原数据内容大小一致, 并且是JPEG 或者 PNG 的格式 (或者是某个resource 与 stream).
- reused的bitmap的configuration值如果有设置，则会覆盖掉inPreferredConfig值.
- 你应该总是使用decode方法返回的bitmap, 因为你不可以假设reusing的bitmap是可用的

### 高效加载大图片(inJustDecodeBounds和inSmapleSize)
如果将inJustDecodeBounds和inSmapleSize设置为true,将不返回bitmap, 但是Bitmap的outWidth,outHeight等属性将会赋值,允许调用查询Bitmap,而不需要为Bitmap分配内存.
例如加载一张很大的位图, 如果直接解码会造成OOM,做法是:
- 先拿到位图的尺寸后,进行放缩后再加载位图
```java
BitmapFactory.Options options = new BitmapFactory.Options();
    options.inJustDecodeBounds = true;
    BitmapFactory.decodeResource(getResources(), R.id.myimage, options);
    int imageHeight = options.outHeight;
    int imageWidth = options.outWidth;
    String imageType = options.outMimeType;
```
- 计算inSampleSize
```java
public static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
    
        if (height > reqHeight || width > reqWidth) {
    
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
    
            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) > reqHeight
                    && (halfWidth / inSampleSize) > reqWidth) {
                inSampleSize *= 2;
            }
        }
    
        return inSampleSize;
    }
```
**设置inSampleSize为2的幂是因为解码器最终还是会对非2的幂的数进行向下处理，获取到最靠近2的幂的数。详情参考inSampleSize的文档**
- 放缩后再加载小位图:
```java
public static Bitmap decodeSampledBitmapFromResource(Resources res, int resId,
        int reqWidth, int reqHeight) {

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(res, resId, options);
    
        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);
    
        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeResource(res, resId, options);
    }
```
### inDither
设置是否抖动处理图片.

### inPremultiplied
- 如果设置了true(默认是true)，那么返回的图片RGB都会预乘透明通道A后的颜色
- 系统View或者Canvas绘制图片,不建议设置为fase,否则会抛出异常,这是因为系统会假定所有图像都预乘A通道的已简化绘制时间.
- 设置inPremultiplied的同时,设置inScale会导致绘制的颜色不正确.
### inMutable
如果设置为true,将返回一个mutable的bitmap,可用于修改BitmapFactory加载而来的bitmap.
- **BitmapFactory.decodeResource(Resources res, int id)**获取到的**bitmap**是**mutable**的，而**BitmapFactory.decodeFile(String path)**获取到的是**immutable**的
- 可以使用**Bitmap copy(Config config, boolean isMutable)**获取mutable位图用于修改位图pixels.

### inDesity
- 设置位图的像素密度，即每英寸有多少个像素
- 如果inScale设置了，同时inDensity的值和inTargetDensity不同时，这个时候图片将缩放位inTartgetDensity指定的值.
- 如果设置为0，则BitmapFactory.decodeResource(Resources,int)和BitmapFactory.decodeResource(Resources, int,BitmapFactory.Options)，BitmapFactory.decodeResourceStream() 将inTargetDensity用DisplayMetrics.densityDpi来设置，其它函数则不会对bitmap进行任何缩放。

### inTargetDensity:
- 设置绘制位图的屏幕密度,与inScale和inDesity一起使用,来对位图进行放缩.
- 如果设置为0， BitmapFactory.decodeResource(Resources,int), BitmapFactory.decodeResource(Resources, int, BitmapFactory.Options),BitmapFactory.decodeResourceStream()将按照DisplayMetrics的density处理.

### inScreenDensity
- 表示正在使用的实际屏幕的像素密度.纯粹用于运行在兼容性代码中的应用程序,其中inTargetDensity实际上是看到的应用程序的密度,而非真正的屏幕密度.
- inDesity, inTargetDensity,inScreenDensity这三个参数主是确定是否需要对bitmap进行缩放处理，如果缩放，缩放后的W和H应该是多少，缩放比例主要是通过：InTargetDenisity/inDensity作为缩放比例。

### inScale
- 当inScale设置为true时,且inDenstiy和inTargetDensity也不为0时,位图将在加载时(解码)时放缩去匹配inTargetDensity,在绘制到canvas时不会依赖图像系统放缩.
- BitmapRegionDecoder会忽略这个标记.
- 此标记默认为true,如果需要非放缩的位图,可以设置为false,9-patch图片会忽略这标记而自动放缩适配.
- 如果inPremultipled设置为false,并且图片有A通道,设置这个标记为true,会导致位图出现不正确的颜色.
### inTargetDensity,inScale,inDesity之间的关系:
说三者之间的关系前,先谈下系统位图放缩规则,做个试验(使用小米3作为测试机):将一张144*144的ic_lanucher.png(系统默认在xxhdpi包下)分别放置在hdpi,xhdpi,xxhdpi三个文件夹,打印出位图的大小.
```java
 Bitmap bitmap = BitmapFactory.decodeResource(this.getResources(), R.drawable.ic_launcher);
   Log.d(TAG, "size:" + bitmap.getByteCount());
```
```
hdpi包size:331776
xhdpi包size:186624
xxhdpi包size:82944
```

我们知道一张144*144的 ic_lanucher.png所占的实际内存为 144*144*4=82944字节,那么为什么同一张图片放在不同包下表现不一样的大小?

屏幕密度与Drawable目录有着如下的关系:
|目录|密度|
|---|---|
|drawable-ldpi|120dpi|
|drawable-mdpi|160dpi|
|drawable-hdpi|240dpi|
|drawable-xhdpi|320dpi|
|drawable-xxhdpi|480dpi|
当使用decodeResuore()解码drawable目录下的图片时, 会根据手机的屏幕密度,到对应的文件夹中查找图片,如果图片存在于其他目录,则会对该图片进行放缩处理在显示,放缩处理的规则:
**scale= 设备屏幕密度/drawable目录设定的屏幕密度**
**图片内存=int(图片长度*scale+0.5f)* int(图片宽度*scale)*单位像素占字节数**
由于实验使用的小米3,屏幕密度为480,则当图片放入在hdpi时:**scale= 480/240**;
图片放入**xhdpi:scale=480/320**;
图片放入**xxhdpi时:scale= 480/480**;

说完系统加载位图使用的放缩规则后,再来说说这三个标记之间的关系:

inDesity: 位图使用的像素密度
inTargetDesity: 设备的屏幕密度
inScale: 是否需要放缩位图

清楚这三者的含义,就可以在加载图片时,根据图片在不同设备上的使用,可以放缩来加载位图:

**放缩规则 scale= inTargetDensity/inDesity;**
```java
BitmapFactory.Options options = new BitmapFactory.Options();
    options.inScaled = true;
    options.inDensity = getBitmapDensity();
    options.inTargetDensity =Resources.getSystem().getDisplayMetrics().densityDpi ;
    Bitmap bitmap1 = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher, options);
```
