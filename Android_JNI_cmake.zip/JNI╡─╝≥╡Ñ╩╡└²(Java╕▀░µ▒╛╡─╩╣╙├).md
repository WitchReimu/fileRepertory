**JNI在Java高版本的使用**

Java在jdk10以后弃用javah命令，而采用javac –h代替。
```cmd
javac -h ./ NativeMethod.java
```
./表示当前这一级文件夹

../表示上一级文件夹

../../表示上上一级文件夹

旧版本jdk内编译jni
```cmd
java-h -jni [文件名]
```